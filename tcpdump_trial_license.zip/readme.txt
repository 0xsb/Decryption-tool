Microolap TCPDUMP for Windows

>>> Important:
1. Microolap TCPDUMP for Windows is free for non-commercial use.
If you are a student or represent a non-commercial organization,
but need the commercial license for some reason, email us at
sales@microolap.com.

2. If you're going to use Microolap TCPDUMP for Windows for business
or government purposes, you're welcome to the order page:
https://microolap.com/tcpdump/order/

3. TCPDUMP for Windows is built with our own traffic capture
technology Packet Sniffer SDK, which is used in EtherSensor as well.
We stopped selling Packet Sniffer SDK in 2008, after the first release
of EtherSensor. Currently we are increasingly receiving requests to
make PSSDK open-source, but we haven't decided yet.
If you want to comment on this issue, please email us.

>>> EtherSensor:
Our flag product is EtherSensor - high-performance software platform
for automatic real-time analysis of application-level network traffic
objects (OSI L7, or even "L8"). Usually it works as a part of Security
Operation Center and provides its results of the network traffic analysis
to SOC subsystems and other corporate systems (DLP, SIEM, U(E)BA,
eDiscovery etc).

Killer features: works on commodity hardware; quite good performance
for such class of software (20+ Gbps, please keep in mind that DLP-like
tasks are much more resource intensive than IPS/IDS or even DPI ones),
real-time detection and analysis of messages of several thousand types.

We sold it since 2008 exclusively in Russia, and in the 2018 fall decided
to localize it into English and offer it to our colleagues abroad. Since
you've downloaded our TCPDUMP for Windows, probably you are
interested in EtherSensor as well - please find its links below:

EtherSensor home page:
https://microolap.com/ethersensor/

EtherSensor FAQ:
https://microolap.com/ethersensor/faq/

EtherSensor on-line manual:
https://microolap.com/ethersensor/manual/

EtherSensor changelog:
https://microolap.com/ethersensor/history/

>>> We are looking for partners:
partners@microolap.com

>>> TCPDUMP links:
Original tcpdump home page:
https://www.tcpdump.org/

Microolap TCPDUMP for Windows home page:
https://microolap.com/tcpdump/

Microolap support:
support@microolap.com

>>> Get notified about new versions.
TCPDUMP Twitter: @tcpdump4windows
TCPDUMP RSS: https://microolap.com/products/network/tcpdump/news/rss
TCPDUMP newsletter: https://microolap.com/newsletter/subscr_edit.php

EtherSensor Twitter: @EtherSensor
EtherSensor RSS: https://microolap.com/products/network/ethersensor/news/rss
EtherSensor newsletter: https://microolap.com/newsletter/subscr_edit.php

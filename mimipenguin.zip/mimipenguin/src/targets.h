#ifndef TARGET_H
#define TARGET_H

#define GNOME_KEYRING_DAEMON "/usr/bin/gnome-keyring-daemon"

char *g_targets[] = {
        GNOME_KEYRING_DAEMON
};

#endif
